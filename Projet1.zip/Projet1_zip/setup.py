# This file contains your application setup code (should be run first and only one time)

def main():
    pass

if __name__ == "__main__":
    main()