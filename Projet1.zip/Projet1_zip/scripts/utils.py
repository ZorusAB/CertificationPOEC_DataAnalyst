import tkinter as tk
from tkinter import ttk
from pymongo import MongoClient
from tkinter import *
def Pagination (collection):
    # # Connexion au serveur Mongo
    # client = MongoClient('mongodb://localhost:27017')
    # # Sélection de la base de données et de la collection
    # db = client['Espace']
    # planet = db['Planete']

    # Paramètres de pagination
    elementsParPage = 30
    pageActuelle = 1

    # Fonction pour récupérer les éléments de la page actuelle
    def obtenirElementsPageActuelle():
        indexDebut = (pageActuelle - 1) * elementsParPage
        elementsPageActuelle = collection.find().skip(indexDebut).limit(elementsParPage)
        return elementsPageActuelle

    # Fonction pour afficher les éléments de la page actuelle
    def afficherPageActuelle():
        elementsPageActuelle = obtenirElementsPageActuelle()
        # Effacer les anciennes données du treeview
        treeview.delete(*treeview.get_children())
        # Ajouter les nouvelles données
        for element in elementsPageActuelle:
            treeview.insert('', 'end', values=tuple(element.values()))

    # Fonction pour passer à la page suivante
    def nextPage():
        global pageActuelle
        pageActuelle += 1
        afficherPageActuelle()

    # Fonction pour passer à la page précédente
    def previousPage():
        global pageActuelle
        if pageActuelle > 1:
            pageActuelle -= 1
            afficherPageActuelle()

    # Création de la fenêtre
    fenetre = tk.Tk()

    # Création du treeview
    treeview = ttk.Treeview(fenetre, height=30)
    treeview.pack()

    # Création des colonnes du treeview
    treeview["columns"] = tuple(collection.find_one().keys())
    treeview.column("#0", width = 0,stretch =NO)
    for column in treeview["columns"]:
        treeview.column(column, width = 75)
        treeview.heading(column, text=column)

    # Création des boutons de navigation
    boutonPrecedent = tk.Button(fenetre, text='Précédent', command=previousPage)
    boutonPrecedent.pack(side=tk.LEFT)
    boutonSuivant = tk.Button(fenetre, text='Suivant', command=nextPage)
    boutonSuivant.pack(side=tk.LEFT)

    # Affichage initial de la première page
    afficherPageActuelle()

    # Lancement de la boucle principale de l'interface graphique
    fenetre.mainloop()
