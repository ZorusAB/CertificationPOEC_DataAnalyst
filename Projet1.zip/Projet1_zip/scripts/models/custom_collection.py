import pymongo
import matplotlib.pyplot as plt
import numpy as np
from tabulate import tabulate

class CustomCollection(pymongo.collection.Collection) :
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs) 


    def telechargement_data(self, requete : dict):

        chemin = input("Veuillez saisir le chemin de téléchargement : ")
        if requete is None :
            req_telechargement = self.find()
        else :
            req_telechargement = self.find(requete)

        with open(chemin, 'w') as file:

            for ele in req_telechargement:

                file.write(str(ele) + '\n')
    
  
    
    
    def exoplanet_per_TypeFlag_tableau(self):

        result_count_by_flag = self.aggregate([
    {"$group": {"_id": "$TypeFlag", "count": {"$sum": 1}}},
    {"$project": {"_id": 0, "TypeFlag": "$_id", "count": 1}}   # Même structure que précédemment
])
        
        table_count_by_flag = [[doc['TypeFlag'], doc['count']] for doc in result_count_by_flag]
        print("Nombre de planètes par type de Flag :")
        print(tabulate(table_count_by_flag, headers=['Type de Flag', 'Nombre de planètes']))


    def exoplanet_per_TypeFlag_pie(self):

        result_count_by_flag = self.aggregate([
    {"$group": {"_id": "$TypeFlag", "count": {"$sum": 1}}},
    {"$project": {"_id": 0, "TypeFlag": "$_id", "count": 1}}   # Même structure que précédemment
])

        type_flag_list =[]
        count_exoplanet = []
        for result in result_count_by_flag :

            type_flag_list.append(result["TypeFlag"])
            count_exoplanet.append(result["count"])

        plt.pie(count_exoplanet, labels = type_flag_list, autopct ='%1.1f%%')
        plt.title("Nombre de planètes découvertes par Type")
        plt.show()



    
    def decouvertes_par_annee_pie(self):
        
        nb_planete_an = self.aggregate([
    {"$group" : {"_id": "$DiscoveryYear",
                 "nb_planet" : { "$sum" : 1}}},
                 { "$sort": { "nb_planet": 1}}
])
        discovery_year = []
        nb_planet_disco= []
        for result in nb_planete_an:
            discovery_year.append(result["_id"])
            nb_planet_disco.append(result["nb_planet"])
    

        plt.pie(nb_planet_disco, labels = discovery_year, autopct='%1.1f%%')
        plt.title("Nombre de planètes découvertes par année")
        plt.show()


    def decouvertes_par_annee_tableau(self):

        result_count_by_method = self.aggregate([
    {"$group": {"_id": "$DiscoveryMethod", "count": {"$sum": 1}}},
    {"$project": {"_id": 0, "DiscoveryMethod": "$_id", "count": 1}} # $project modifie la structure des éléments de
])                                                                  # sortie



        # Récupération de nos aggrégats sous la forme d'une liste depuis le cursor mongo
        table_count_by_method = [[doc['DiscoveryMethod'], doc['count']] for doc in result_count_by_method]

        print("Nombre d'exoplanètes par méthode :")
        print(tabulate(table_count_by_method, headers=['Méthode de découverte', 'Nombre d\'exoplanètes']))
        

      ## Réflechir à comment afficher soit le tableau soit un diagramme

    def densite_etoile_hote_per_exoplanet_eccentricity(self):
        
        etoile_den = self.find()
        list_density = []
        list_ecc = []

        for element in etoile_den :
            if not np.isnan(element["HostStarMassSlrMass"]) and not np.isnan(element["HostStarRadiusSlrRad"]) and not np.isnan(element["Eccentricity"]):
                masse_etoile = element["HostStarMassSlrMass"]
                rayon_etoile = element["HostStarRadiusSlrRad"]
        ## Définition de la densité et remplissage en liste
                density = 3*masse_etoile/(4*np.pi*rayon_etoile**3) 
        
        ## On écarte les densités trop forte pour pouvoir plotter correctement
                if density < 1 :
                    list_density.append(density)
                    list_ecc.append(element["Eccentricity"])
        

        ## Affichage du tableau sous nuage de points 
        plt.scatter(list_ecc, list_density,s=3 )  # s correspond à la taille des points
        plt.title("Exentricité des planètes selon la densité de leur étoile")
        plt.xlabel('Eccentricity')
        plt.ylabel('Density')
        plt.show()


    def densite_exoplanet_per_eccentricity(self):

        planet_den = self.find()
        list_density_p = []
        list_ecc_p = []

        for element in planet_den :
            if not np.isnan(element["PlanetaryMassJpt"]) and not np.isnan(element["RadiusJpt"]) and not np.isnan(element["Eccentricity"]):
                masse_planete = element["PlanetaryMassJpt"]
                rayon_planete = element["RadiusJpt"]
                density_planete = 3*masse_planete/(4*np.pi*rayon_planete**3) 
                if density_planete < 40 :
                    list_density_p.append(density_planete)
                    list_ecc_p.append(element["Eccentricity"])

        ## Affichage du tableau sous nuage de points 
        plt.scatter(list_ecc_p, list_density_p,s=3 )
        plt.title("Exentricité des planètes selon leur densité")
        plt.xlabel('Eccentricity')
        plt.ylabel('Density')
        plt.show()


    def rapport_densite_exoplanet_etoile_per_eccentricity(self):

        etoile_planet = self.find()
        list_density_per= []
        list_ecc_per = []

        for element in etoile_planet :
            if not np.isnan(element["HostStarMassSlrMass"]) and not np.isnan(element["HostStarRadiusSlrRad"]) and not np.isnan(element["Eccentricity"]) and not np.isnan(element["PlanetaryMassJpt"]) and not np.isnan(element["RadiusJpt"]):
        
                
        ## Récupération du poids et rayons des etoiles et des planetes
                masse_etoile = element["HostStarMassSlrMass"]
                rayon_etoile = element["HostStarRadiusSlrRad"]
                masse_planete = element["PlanetaryMassJpt"]
                rayon_planete = element["RadiusJpt"]
        ## Définition de la densité et remplissage en liste
                density_etoile = 3*masse_etoile/(4*np.pi*rayon_etoile**3) 
                density_planete = 3*masse_planete/(4*np.pi*rayon_planete**3) 
        # print(density, element["Eccentricity"])
                
        ## On écarte les densités trop forte
                if (density_etoile < 1) and (density_planete < 40) and (density_etoile / density_planete < 10) :
            # density_rapport = density_p / density_e
                    density_rapport = density_etoile / density_planete
                    list_density_per.append(density_rapport)
                    list_ecc_per.append(element["Eccentricity"])

        plt.scatter(list_ecc_per, list_density_per,s=3 )
        plt.title("Rapport densité étoile_hôte/planète en fonction de l'exentricité de la planète")
        plt.xlabel('Eccentricity')
        plt.ylabel('Rapport Densité')
        plt.show()




