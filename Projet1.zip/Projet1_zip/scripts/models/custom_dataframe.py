import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats
from scipy.stats import chi2_contingency
import seaborn as sns
import os


class CustomDataframe(pd.DataFrame):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)     # Ici on effectue une surcharge pour que nos objets de la classe enfant
                                              # héritent des mêmes 



    def nettoyage_basique(self):

        taille_init = self.shape
        self.drop(labels=['AgeGyr', 'LongitudeDeg', 'AscendingNodeDeg', 'PeriastronDeg', 'HostStarAgeGyr', 'InclinationDeg', 'LastUpdated'], axis=1, inplace = True)  # Retrait des variables qui sont très peu référencées
        
        # Suppression des doublons
        self.drop_duplicates(inplace=True)

        # subset=['TypeFlag', 'PlanetaryMassJpt', 'RadiusJpt', 'SemiMajorAxisAU', 'Eccentricity', 'SurfaceTempK',
        #'DiscoveryMethod', 'DiscoveryYear', 'RightAscension', 'Declination', 'DistFromSunParsec', 'HostStarMassSlrMass', 'HostStarRadiusSlrRad', 
        # 'HostStarMetallicity', 'HostStarMetallicity', 'HostStarTempK', 'ListsPlanetIsOn']

        # Traitement de la variable ListsPlanetIsOn

        self.loc[self['ListsPlanetIsOn'] == 'Confirmed planets, Planets in binary systems, S-type', 'ListsPlanetIsOn'] = 'Confirmed planets'

        self.loc[self['ListsPlanetIsOn'] == 'Confirmed planets, Planets in binary systems, P-type', 'ListsPlanetIsOn'] = 'Confirmed planets'

        self.loc[self['ListsPlanetIsOn'] == 'Controversial, Planets in binary systems, S-type', 'ListsPlanetIsOn'] = 'Controversial'

        self.loc[self['ListsPlanetIsOn'] == 'Confirmed planets, Planets in open clusters', 'ListsPlanetIsOn'] = 'Confirmed planets'

        self.loc[self['ListsPlanetIsOn'] == 'Controversial, Planets in binary systems, P-type', 'ListsPlanetIsOn'] = 'Controversial'

        self.loc[self['ListsPlanetIsOn'] == 'Confirmed planets, Orphan planets', 'ListsPlanetIsOn'] = 'Confirmed planets'

        self.loc[self['ListsPlanetIsOn'] == 'Confirmed planets, Planets in binary systems, P-type, Planets in globular clusters', 'ListsPlanetIsOn'] = 'Confirmed planets'

        self.loc[self['ListsPlanetIsOn'] == 'Planets in binary systems, S-type, Confirmed planets', 'ListsPlanetIsOn'] = 'Confirmed planets'

        
        # Création d'une variable type de trajectoire à partir de l'eccentricité
        
        for index, row in self.iterrows():
            val = row['Eccentricity']
            
            # si la valeur est zéro, assigner la cercle au nouveau champ  #### Regarder switch case si temps
            
            if val == 0:
                self.loc[index, 'Trajectoire'] = 'Cercle'
            elif val  > 1:
                self.loc[index, 'Trajectoire'] = 'Hyperbole'
            elif val <  1:
                self.loc[index, 'Trajectoire'] = 'Ellipse'
            elif val == 1 :
                self.loc[index, 'Trajectoire'] = 'Parabole'
            else:
                self.loc[index, 'Trajectoire'] = 'Trajectoire inconnue'

    ############## Suppression des valeurs extrêmes pour chaque variable quantitative:
                
     # Sélection des variables quantitatives
        df_numeric_columns = self.select_dtypes(include=['int64', 'float64'])
        
        # Récupération des quantiles extrèmes pour un filtrage de nos données, utile pour mieux visualiser des phénomènes

        lower_quantiles = df_numeric_columns.quantile(0.005) 
        upper_quantiles = df_numeric_columns.quantile(0.995) 

        # Filtrage complet de notre jeu en retirant les valeurs extrêmes pour chaque variable quantitative
        # Ici test sera notre jeu que nous chercherons à filtrer

        for col in df_numeric_columns:
            self = self[((self[col] >= lower_quantiles[col]) & (self[col] <= upper_quantiles[col]))|pd.isna(self[col])]
        
        taille_finale = self.shape
        print(f"Nous avons réduit notre jeu de données de {taille_init[0]-taille_finale[0]} entrées et de {taille_init[1]-taille_finale[1]} colonnes")
        
        return self

        
        

    def get_visual_analytics_hist(self):

        
        
        list_hist = ['TypeFlag', 'DiscoveryMethod', 'DiscoveryYear', 'ListsPlanetIsOn'] # + new_Eccentricity

        # Création d'une nouvelle liste, intersection avec les colonnes de notre jeu de données, pour être sûr de
        # compiler les bons diagrammes
        list_hist_full = list(set(list_hist).intersection(list(self.columns)))

        for col in list_hist_full:
            distribution = self[col].value_counts()
            distribution.plot(kind='bar')
            plt.show()

    def get_visual_analytics_boxplot(self):
        
        list_boxplot = ['PlanetaryMassJpt', 'RadiusJpt', 'SemiMajorAxisAU', 'Eccentricity', 'PeriastronDeg',
       'LongitudeDeg', 'AscendingNodeDeg', 'SurfaceTempK', 'DiscoveryYear','DistFromSunParsec',
       'HostStarMassSlrMass', 'HostStarMetallicity',
       'HostStarTempK', 'HostStarAgeGyr']

        list_boxplot_full = list(set(list_boxplot).intersection(list(self.columns)))

        for col in list_boxplot_full:
            sns.boxplot(x=self[col])
            plt.show()

    def get_visual_analytics_densityhist(self):
        
        chemin = input("Veuillez saisir le chemin de sauvegarde : ")
        
        list_dens = ['TypeFlag', 'RadiusJpt', 'Eccentricity', 'PeriastronDeg',
       'LongitudeDeg', 'AscendingNodeDeg', 'SurfaceTempK', 'DiscoveryMethod','DistFromSunParsec',
       'HostStarMassSlrMass', 'HostStarRadiusSlrRad', 'HostStarMetallicity',
       'HostStarTempK', 'HostStarAgeGyr', 'ListsPlanetIsOn']

        list_densityhist_full = list(set(list_dens).intersection(list(self.columns)))

        if not os.path.exists(chemin):
                os.makedirs(chemin)
        for col in list_densityhist_full:
            sns.displot(data=self[list_densityhist_full], x= col, kde=True)
            plt.show()
            plt.savefig(chemin)
            plt.close()

    def heatmap_missing_values(self):

        missing_values = self.isnull()

        sns.heatmap(missing_values, cbar=False) ## Crée une heatmap des valeurs manquantes
        plt.show()
        
    def missing_values_by_column(self):

        dict_missing_values = {}
        
        for col in self.columns:
    
            dict_missing_values[col] = self[col].isnull().sum()/self.shape[0]

        # Récupération de tuples (clé,valeurs) de notre dictionnaire puis classement par valeur décroissante:
        sorted(dict_missing_values.items(), key=lambda item: item[1], reverse=True)

        # Le plot sera fait à partir d'un dictionnaire:
        dict_trie = {cle: valeur for cle, valeur in sorted(dict_missing_values.items(), key=lambda item: item[1], reverse=False)}

        # Plot de la qualité de remplissage de chacun des observables dans notre jeu, trié du moins rempli au plus rempli

        plt.barh(list(dict_trie.keys()), list(dict_trie.values()))
        plt.ylabel('Clés')
        plt.xlabel('Pourcentage de valeurs manquantes')
        plt.title('Pourcentage de valeurs manquantes par colonne de notre jeu')
        plt.show()


    def etude_correlations_qte(self):
        

        numeric_columns = self.select_dtypes(include=['int64', 'float64'])

        # Calculer la matrice de corrélation
        correlation_matrix = numeric_columns.corr()

        # Afficher la matrice de corrélation avec une heatmap
        plt.figure(figsize=(20, 10))
        sns.heatmap(correlation_matrix, annot=True, fmt=".1f", cmap="RdYlBu")


        plt.title("Matrice de corrélation")
        plt.show()

    def anova_complete(self):

        liste_var_pas_utiles = ['PlanetIdentifier','LastUpdated', 'RightAscension', 'Declination']
        list_obj_anova_full_inutile = list(set(liste_var_pas_utiles).intersection(list(self.columns)))

        list_numeric = ['TypeFlag', 'PlanetaryMassJpt', 'RadiusJpt', 'PeriodDays',
       'SemiMajorAxisAU', 'Eccentricity', 'PeriastronDeg', 'LongitudeDeg',
       'AscendingNodeDeg', 'InclinationDeg', 'SurfaceTempK',
       'DiscoveryYear', 'DistFromSunParsec', 'HostStarMassSlrMass',
       'HostStarRadiusSlrRad', 'HostStarMetallicity', 'HostStarTempK',
       'HostStarAgeGyr']

        list_numeric_anova_full = list(set(list_numeric).intersection(list(self.columns)))

            
        df_obj_columns = self.select_dtypes(exclude=['int64', 'float64']) # On ne garde que les colonnes objets ici, puis nettoyage 
                                                                          # léger
        df_obj_columns = df_obj_columns.drop(list_obj_anova_full_inutile, axis =1)

        # Boite à moustaches pour chaque valeur d'une même variable catégorielle vis-à-vis de chaque variable
# quantitative, pour regarder les comportements des groupes

        for cat in df_obj_columns.columns:
            for quantitative in list_numeric_anova_full:
                df_anova = self[[cat, quantitative]].dropna() #On ne récupère que les données pertinentes
                print(df_anova.isna().sum().sum())
                result_anova = stats.f_oneway(*[group[quantitative] for name, group in df_anova.groupby(cat)])
                print(f"Résultats de l'ANOVA pour {quantitative} par valeurs de {cat}")
                print("Valeur de F =", result_anova.statistic)
                print("Valeur de p =", result_anova.pvalue)
                sns.boxplot(data=df_anova, x= cat, y= quantitative, showmeans =True, meanprops={"marker":"o",
                       "markerfacecolor":"white", 
                       "markeredgecolor":"black",
                      "markersize":"10"})
                plt.show()
        #print(sns.stripplot(x= cat, y= quantitative,data=df_anova))
        
                if result_anova.pvalue <= 0.05:
                    print("Nous rejetons l'hypothèse nulle")
                else :
                    print("L'hypothèse nulle est vérifiée, il n'y a pas de différence significative au sein des groupes")
        

                print('------------------------------------')

        
    




    def chi2_test(self):

        list_chi2 = ['DiscoveryMethod', 'ListsPlanetIsOn']

        # Création d'une matrice de contingence
        
        contingency_table = pd.crosstab(self["DiscoveryMethod"], self["ListsPlanetIsOn"])
        
        # Test Chi-2 :
        
        chi2, p_value, _, _ = chi2_contingency(contingency_table)
        print(f"Statistique du test du khi-deux :{chi2}")
        print(f"Valeur de p :{p_value}")
        if p_value <= 0.05:
            print("L'hypothèse nulle est rejetée, les variables étudiées ne sont pas indépendantes")






        # Création d'un diagramme en barres empilées
        contingency_table.plot(kind='bar', stacked=True)
        plt.xlabel("Catégories de DiscoveryMethod")
        plt.ylabel("Fréquences observées")
        plt.title("Diagramme en barres empilées des fréquences observées")
        plt.legend(title="ListsPlanetIsOn")
        plt.show()
        print('-------------------------------------------------------------------------')

############ Peu lisible ??

        # Création d'un diagramme en mosaïque
        sns.heatmap(contingency_table, annot=True, fmt="d", cmap="YlGnBu")
        plt.xlabel("ListsPlanetIsOn")
        plt.ylabel("DiscoveryMethod")
        plt.title("Diagramme en mosaïque des fréquences observées")
        plt.show()




        contingency_table_2 = pd.crosstab(self["DiscoveryMethod"], self["Trajectoire"])
        
        # Test Chi-2 :
        
        chi2, p_value, _, _ = chi2_contingency(contingency_table_2)
        print(f"Statistique du test du khi-deux :{chi2}")
        print(f"Valeur de p :{p_value}")
        if p_value <= 0.05:
            print("L'hypothèse nulle est rejetée, les variables étudiées ne sont pas indépendantes")






        # Création d'un diagramme en barres empilées
        contingency_table_2.plot(kind='bar', stacked=True)
        plt.xlabel("Catégories de DiscoveryMethod")
        plt.ylabel("Fréquences observées")
        plt.title("Diagramme en barres empilées des fréquences observées")
        plt.legend(title="Trajectoire")
        plt.show()
        print('-------------------------------------------------------------------------')

############ Peu lisible ??

        # Création d'un diagramme en mosaïque
        sns.heatmap(contingency_table_2, annot=True, fmt="d", cmap="YlGnBu")
        plt.xlabel("Trajectoire")
        plt.ylabel("DiscoveryMethod")
        plt.title("Diagramme en mosaïque des fréquences observées")
        plt.show()





        contingency_table_3 = pd.crosstab(self["Trajectoire"], self["ListsPlanetIsOn"])
        
        # Test Chi-2 :
        
        chi2, p_value, _, _ = chi2_contingency(contingency_table_3)
        print(f"Statistique du test du khi-deux :{chi2}")
        print(f"Valeur de p :{p_value}")
        if p_value <= 0.05:
            print("L'hypothèse nulle est rejetée, les variables étudiées ne sont pas indépendantes")






        # Création d'un diagramme en barres empilées
        contingency_table_3.plot(kind='bar', stacked=True)
        plt.xlabel("Catégories de Trajectoire")
        plt.ylabel("Fréquences observées")
        plt.title("Diagramme en barres empilées des fréquences observées")
        plt.legend(title="ListsPlanetIsOn")
        plt.show()
        print('-------------------------------------------------------------------------')

############ Peu lisible ??

        # Création d'un diagramme en mosaïque
        sns.heatmap(contingency_table_3, annot=True, fmt="d", cmap="YlGnBu")
        plt.xlabel("ListsPlanetIsOn")
        plt.ylabel("Trajectoire")
        plt.title("Diagramme en mosaïque des fréquences observées")
        plt.show()









