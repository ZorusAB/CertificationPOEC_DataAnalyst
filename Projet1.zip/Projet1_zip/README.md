# <b>Les ExoPlanètes</b>

<b>Notre application permet d'afficher des informations sur des exoplanètes découvertes</b>

Le fichier de données est très incomplet, certaines colonnes sont remplis à moins de 50%

## <u><b>Colonnes du fichier et explication de leur signification</u></b>

|PlanetIdentifier| Nom de la planète|
|TypeFlag | Type de planètes|
|PlanetaryMassJpt | Masse de la planètes en fonction de celle de Jupiter|
|RadiusJpt | Rayon de la planète en fonction de celle de Jupiter|
|SemiMajorAxisAU | Demi grand axe de la trajectoire|
|Eccentricity | Excentricité de la planète représentant l'étirage du cercle de trajectoire|
|SurfaceTempK | Température à la surface de la planète en Kelvin|
|DiscoveryMethod | Méthode de découverte de la planète|
|DiscoveryYear | Année de découverte de la planète|
|RightAscension | Temps nécessaire à parcourir l'ascencion haute
|Declination | Temps nécessaire à faire une révolution complète
|DistFromSunParsec | Distance de la planète par rapport au Soleil|
|HostStarMassSlrMass | Masse de l'étoile mère de la planète|
|HostStarRadiusSlrRad | Rayon de l'étoile mère de la planète|
|HostStarMetallicity | Mettalicité de l'étoile mère de la planète|
|HostStarTempK | Température de l'étoile mère de la planète|
|ListsPlanetIsOn | Type de planète, controversée ou non identifiée|
|Trajectoire | Trajectoire de la planète|

***La Pagination :***
Un système de pagination a été mis en place sur le set de données de départ nettoyer. Ce système permet d'afficher 30 lignes à la fois. Un bouton "Next" et un bouton "Previous" pour se balader dans le fichier.

L'application a été créee de façon à afficher des données en cliquant sur des boutons
## <u><b>Liste des boutons :</b><u/>

Afficher les données : *Affiche un tableau du jeu de données complet*

Map value des valeurs manquantes : *HeatMap de remplissage des colonnes du fichier de départ*

Valeurs manquantes par colonnes : *Pourcentage de valeurs manquantes par colonne*

Histogramme : *Affiche une liste d'histogramme*

Boîtes à moustaches : *Affiche une liste de boîte à moustaches*

Histogramme density : *Affiche les histogrammes de densité*

Corrélation : *Affiche la HeatMap des corrélations de valeurs entre elles*

ANOVA : *Test statistique cherchant des liens entre une variable catégorielle et une variable quantitative. On pose une hypothèse H0 : Il n'y a pas de différence significative entre les moyennes des groupes pour l'observable. Il en résulte deux valeurs : F basée sur le rapport de deux variances : la variance entre les groupes (variance intergroupe) et la variance à l'intérieur des groupes (variance intragroupe). Quand F est grand cela stipule qu'il y a une variation significative entre les groupes.*
 *p la probabilité un F aussi extrême que celui observé, si p < 0.05 on considère que la différence observée est significative et H0 est rejetée.*

Chi2-Test : *Test statistique qui cherche à évaluer des liens entre deux variables catégorielles. H0 : il n'y a aucune différence significative entre les fréquences observées et les fréquences attendues, ce qui signifie que les variables étudiées sont indépendantes.*

*Ces fréquences observées/attendues sont comparées*

Télécharger les données : *Permet de télécharger un fichier de données*

Tableau Type Flag : *Affiche sous forme de tableau le nombre de planètes par type*

Pie Chart Type Flag : *Affiche sous forme de cammembert le nombre de planètes par type*

Pie Chart Découverte par Années : *Affichage sous forme de cammembert du nombre de planètes découverte par années*

Tableau Découverte par Années : *Affichage sous forme de tableau du nombre de planètes découverte par années* 

Densité Étoile Hôte  Eccentricity : *Excentricité en fonction de la densité de l'étoile mère*

Densité Exoplanète par Eccentricity :*Excentricité en fonction de la densité de la planète*

Bouton 16 : *Affiche le rapport de densité exoplanete/etoile-hôte en fonction de l'eccentricité*
