import tkinter as tk             
from tkinter import ttk
import pandas as pd

from scripts.models import CustomDataframe, CustomCollection, MongoDBSingleton

def main():
    # Instanciation du client MongoDB, de la db et de notre collection.
    client = MongoDBSingleton.get_instance()
    db = client.db
    #collection =  client.get_collection('Exoplanètes')
    collection = CustomCollection(db, 'Exoplanètes')
    print(type(collection))


    # Récupération de nos données et intégration dans la collection

    #importer les donnéees sous forme de dataframe pandas
    path='assets/oec.csv'

    def lecture_donnee(path):
        dataframe=pd.read_csv(path)
        df = CustomDataframe(dataframe)
        return df
        
    
    df = lecture_donnee(path)  #Lecture au format CustomDataframe
    print(df.shape)
    print(type(df))

    df = CustomDataframe(df.nettoyage_basique())      # Nettoyage
    print(df.shape)
    print('---------------')
    print(type(df))

    df_dict=df.to_dict(orient='records') # Instanciation d'un dictionnaire contenant nos données

    collection.insert_many(df_dict)      # Insert des données sur mongoDB
    
    # Création de la fenêtre principale
    fenetre_principale = tk.Tk()
    fenetre_principale.title("Tkinter des Exoplanètes")
    fenetre_principale.geometry("800x600")
# Message de bienvenue
    message_bienvenue = ttk.Label(fenetre_principale, text="Bienvenue dans l'application des exoplanètes !", foreground="green")
    message_bienvenue.pack(pady=30)

# Frame pour les boutons de gauche (boutons 1 à 8)
    frame_gauche = tk.Frame(fenetre_principale)
    frame_gauche.pack(side=tk.LEFT, padx=20)

# Liste des noms des boutons de gauche
    bouton_noms_gauche = [
    "HeatMap des valeurs manquantes",
    "Valeurs manquantes par colonnes (%)",
    "Histogrammes",
    "Boîtes à moustaches",
    "Histogramme à densité",
    "Corrélations",
    "ANOVA",
    "Chi2-Test"
]

    #Fonction d'affichage des données
    def afficher_donnees():
        fenetre = tk.Toplevel()
        fenetre.title("Données")
        fenetre.geometry("1400x1400")

    # Créer un widget Treeview pour afficher les données
        treeview = ttk.Treeview(fenetre)
        treeview.pack(fill=tk.BOTH, expand=True)

    # Définir les colonnes du Treeview
        columns = list(df.columns)
        treeview["columns"] = columns

    # Définir les en-têtes de colonne
        for col in columns:
            treeview.heading(col, text=col)

    # Insérer les données dans le Treeview
        for index, row in df.iterrows():
            treeview.insert("", "end", text=index, values=list(row))






    
    # Action relatives aux customDataFrame
    
    def action_1():

        df.heatmap_missing_values()

    def action_2():
        
        df.missing_values_by_column()

    def action_3():

        df.get_visual_analytics_hist()
        

    def action_4():

        df.get_visual_analytics_boxplot()

    def action_5():

        df.get_visual_analytics_densityhist()
        
    def action_6():

        df.etude_correlations_qte()

    def action_7():

        df.anova_complete()

    def action_8():

        df.chi2_test()
        
    # Actions relatives aux customcollections
    
    def action_9():

        collection.telechargement_data(collection)


    def action_10():

        collection.exoplanet_per_TypeFlag_tableau()

    def action_11():

        collection.exoplanet_per_TypeFlag_pie()

    def action_12():

        collection.decouvertes_par_annee_pie()

    def action_13():

        collection.decouvertes_par_annee_tableau()

    def action_14():

        collection.densite_etoile_hote_per_exoplanet_eccentricity()

    def action_15():

        collection.densite_exoplanet_per_eccentricity()

    def action_16():

        collection.rapport_densite_exoplanet_etoile_per_eccentricity()


    # Création des boutons de gauche avec une boucle for
    for i, nom in enumerate(bouton_noms_gauche, start=1):
        bouton = ttk.Button(frame_gauche, text=nom, width=30, style="Custom.TButton", command=eval(f"action_{i}"))
        bouton.pack(pady=12)
    
        
# Création des boutons de gauche avec une boucle for
    #for i, nom in enumerate(bouton_noms_gauche, start=1):
    #    bouton = ttk.Button(frame_gauche, text=nom, width=30, style="Custom.TButton")
     #   bouton.pack(pady=5)

# Frame pour les boutons de droite (boutons 9 à 16)
    frame_droite = tk.Frame(fenetre_principale)
    frame_droite.pack(side=tk.RIGHT, padx=20)

# Liste des noms des boutons de droite
    bouton_noms_droite = [
    "Télécharger les données",
    "Tableau Count Type Flag",
    "Camembert Type Flag",
    "Camembert Découverte par Années",
    "Count Tab Découverte par Années",
    "Densité Étoile-Hôte/Eccentricity",
    "Densité Exoplanète/Eccentricity",
    "Rapport Densité Exo/Hote / Ecc"
]

    #bouton = ttk.Button(frame_droite, text="Tableau Count Type Flag2", width=30, style="Custom.TButton", command=lambda: collection.exoplanet_per_TypeFlag_tableau())
    #bouton.pack(pady=12)

# Création des boutons de droite avec une boucle for
    for i, nom in enumerate(bouton_noms_droite, start=9):
        bouton = ttk.Button(frame_droite, text=nom, width=30, style="Custom.TButton", command=eval(f"action_{i}"))
        bouton.pack(pady=12)


# Bouton pour afficher les données (en haut)
    bouton_afficher_donnees = ttk.Button(fenetre_principale, text="Affichage des données", width=20, style="Custom.TButton", command=afficher_donnees)
    bouton_afficher_donnees.pack(pady=12)

# Style pour les boutons
    style = ttk.Style()
    style.configure("Custom.TButton", foreground="green", background="white", font="Arial 12", relief="raised", borderwidth=0, highlightthickness=0, activebackground="#4799E5")

# Lancement de la boucle principale Tkinter
    fenetre_principale.mainloop()
    
        
    
    pass    
    
if __name__ == "__main__":
    main()
